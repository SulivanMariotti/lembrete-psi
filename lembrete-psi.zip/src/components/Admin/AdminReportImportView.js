
"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  FileDown,
  FileSpreadsheet,
  Layers3,
  PencilLine,
  Plus,
  RefreshCcw,
  Save,
  Tags,
  Trash2,
  Upload,
} from "lucide-react";

import { adminFetch } from "../../services/adminApi";
import { Badge, Button, Card } from "../DesignSystem";
import { REPORT_IMPORT_TEMPLATE } from "../../lib/shared/reportImportTemplate";
import {
  REPORT_DEMAND_CATEGORY_OPTIONS,
  countFilledDemandCategories,
  createEmptyDemandForm,
  mapDemandToForm,
} from "../../lib/shared/reportDemands";
import {
  REPORT_SPECIALTY_DEMAND_SOURCE_MODES,
  createEmptySpecialtyForm,
  mapSpecialtyToForm,
} from "../../lib/shared/reportSpecialties";
import {
  REPORT_TEMPLATE_FORMATTING_ACTIONS,
  REPORT_TEMPLATE_LOGO_MAX_DATA_URL_LENGTH,
  createEmptyTemplateForm,
  mapTemplateToForm,
  buildTemplateSummary,
  getAllTemplateTags,
  buildTemplateRenderBlocks,
  findUnknownTemplateTokens,
} from "../../lib/shared/reportTemplates";

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (!value) return "0 B";
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / (1024 * 1024)).toFixed(2)} MB`;
}

function formatSessionExpiry(expiresAt) {
  if (!expiresAt) return "—";
  const value =
    typeof expiresAt === "number"
      ? expiresAt
      : typeof expiresAt === "string"
        ? new Date(expiresAt).getTime()
        : Number(expiresAt);
  if (!Number.isFinite(value)) return "—";
  return new Date(value).toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function buildTemplateErrorState(data = {}) {
  const validation = data?.validation || {};
  return {
    code: String(data?.code || "invalid-template-headers"),
    error: String(data?.error || "A planilha não corresponde ao template esperado."),
    validation,
    missingHeaders: Array.isArray(validation?.missingHeaders) ? validation.missingHeaders : [],
    extraHeaders: Array.isArray(validation?.extraHeaders) ? validation.extraHeaders : [],
    expectedCount: Number(validation?.expectedCount || 0),
    receivedCount: Number(validation?.receivedCount || 0),
  };
}

function formatDateTime(value) {
  const numeric = Number(value || 0);
  if (!numeric) return "—";
  try {
    return new Date(numeric).toLocaleString("pt-BR");
  } catch (_) {
    return "—";
  }
}

function categoryStatusToBadge(status) {
  if (status === "ready") return { status: "confirmed", text: "Pronto" };
  if (status === "missing-specialty") return { status: "missing", text: "Especialidade em branco" };
  if (status === "specialty-not-found") return { status: "missing", text: "Especialidade não encontrada" };
  if (status === "inactive-specialty") return { status: "pending", text: "Especialidade inativa" };
  if (status === "psychology-missing-demand") return { status: "missing", text: "Psicologia sem Demanda" };
  if (status === "psychology-demand-not-found") return { status: "missing", text: "Demanda da Psicologia não encontrada" };
  if (status === "specialty-without-default-demand") return { status: "missing", text: "Sem Demanda padrão" };
  if (status === "inactive-demand") return { status: "pending", text: "Demanda inativa" };
  if (status === "missing-category") return { status: "missing", text: "Categoria vazia" };
  return { status: "pending", text: "Pendente" };
}

function buildDemandPreviewLabel(item) {
  const filled = countFilledDemandCategories(item);
  const suffix = filled === 1 ? "categoria preenchida" : "categorias preenchidas";
  const cidParts = [];
  if (String(item?.cidInf || "").trim()) cidParts.push("CID Inf");
  if (String(item?.cidAdult || "").trim()) cidParts.push("CID Adult");
  const cidLabel = cidParts.length ? ` • ${cidParts.join(" + ")}` : " • sem CID";
  return `${filled}/5 ${suffix}${cidLabel}`;
}

function specialtyModeToLabel(mode) {
  if (mode === REPORT_SPECIALTY_DEMAND_SOURCE_MODES.SYSTEM_DEFAULT) {
    return "Demanda do sistema";
  }
  return "Demanda do arquivo";
}

function specialtyModeToHint(mode) {
  if (mode === REPORT_SPECIALTY_DEMAND_SOURCE_MODES.SYSTEM_DEFAULT) {
    return "Nutrição e Fonoaudiologia podem usar Demanda padrão do sistema e deixar a Demanda do arquivo vazia.";
  }
  return "A Especialidade espera a Demanda no arquivo. Psicologia segue essa regra.";
}

function readLogoAsJpegDataUrl(file) {
  return new Promise((resolve, reject) => {
    if (!file) {
      reject(new Error("Arquivo de logo não informado."));
      return;
    }

    if (typeof window === "undefined") {
      reject(new Error("Upload de logo disponível apenas no navegador."));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Não foi possível ler a imagem."));
    reader.onload = () => {
      const image = new window.Image();
      image.onerror = () => reject(new Error("Não foi possível abrir a imagem."));
      image.onload = () => {
        const maxWidth = 520;
        const maxHeight = 180;
        const scale = Math.min(maxWidth / image.width, maxHeight / image.height, 1);
        const width = Math.max(1, Math.round(image.width * scale));
        const height = Math.max(1, Math.round(image.height * scale));

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const context = canvas.getContext("2d");

        if (!context) {
          reject(new Error("Não foi possível preparar a logo para o relatório."));
          return;
        }

        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, width, height);
        context.drawImage(image, 0, 0, width, height);

        const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
        resolve(dataUrl);
      };

      image.src = String(reader.result || "");
    };

    reader.readAsDataURL(file);
  });
}


function TemplateTagToolbar({ onInsert }) {
  const groups = useMemo(() => getAllTemplateTags(), []);
  const [selectedGroupKey, setSelectedGroupKey] = useState(groups[0]?.key || "spreadsheet");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTag, setSelectedTag] = useState("");

  const selectedGroup = useMemo(
    () => groups.find((group) => group.key === selectedGroupKey) || groups[0] || null,
    [groups, selectedGroupKey]
  );

  const filteredItems = useMemo(() => {
    const normalizedQuery = String(searchTerm || "").trim().toLowerCase();
    const items = Array.isArray(selectedGroup?.items) ? selectedGroup.items : [];
    if (!normalizedQuery) return items;

    return items.filter((item) => {
      const haystack = `${item?.label || ""} ${item?.token || ""} ${item?.tag || ""}`.toLowerCase();
      return haystack.includes(normalizedQuery);
    });
  }, [searchTerm, selectedGroup]);

  useEffect(() => {
    if (!filteredItems.length) {
      setSelectedTag("");
      return;
    }

    if (selectedTag && filteredItems.some((item) => item.tag === selectedTag)) {
      return;
    }

    setSelectedTag(filteredItems[0].tag);
  }, [filteredItems, selectedTag]);

  const handleInsert = () => {
    if (!selectedTag) return;
    onInsert(selectedTag);
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-3 md:grid-cols-2">
        <label className="space-y-1.5 text-sm text-slate-600">
          <span className="font-semibold text-slate-800">Origem do campo</span>
          <select
            value={selectedGroupKey}
            onChange={(event) => {
              setSelectedGroupKey(event.target.value);
              setSearchTerm("");
            }}
            className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus:border-violet-400"
          >
            {groups.map((group) => (
              <option key={group.key} value={group.key}>
                {group.label}
              </option>
            ))}
          </select>
        </label>

        <label className="space-y-1.5 text-sm text-slate-600">
          <span className="font-semibold text-slate-800">Buscar campo</span>
          <input
            type="text"
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="Digite parte do nome do campo ou da TAG"
            className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none placeholder:text-slate-400 focus:border-violet-400"
          />
        </label>
      </div>

      <label className="space-y-1.5 text-sm text-slate-600">
        <span className="font-semibold text-slate-800">Campo disponível</span>
        <select
          value={selectedTag}
          onChange={(event) => setSelectedTag(event.target.value)}
          className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus:border-violet-400"
        >
          {filteredItems.length ? (
            filteredItems.map((item) => (
              <option key={`${selectedGroup?.key || "group"}-${item.token}`} value={item.tag}>
                {item.label} — {item.tag}
              </option>
            ))
          ) : (
            <option value="">Nenhum campo encontrado</option>
          )}
        </select>
      </label>

      <div className="rounded-xl border border-slate-100 bg-slate-50 px-4 py-3 text-sm text-slate-600">
        TAG selecionada:{" "}
        <span className="font-mono font-semibold text-violet-700">{selectedTag || "—"}</span>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Button type="button" onClick={handleInsert} disabled={!selectedTag}>
          Inserir no texto
        </Button>
        <div className="text-xs text-slate-500">
          Escolha a origem, procure o campo e insira a TAG no ponto do cursor.
        </div>
      </div>
    </div>
  );
}


function TemplateFormattingToolbar({ onAction }) {
  return (
    <div className="flex flex-wrap gap-2 rounded-2xl border border-slate-100 bg-slate-50 p-3">
      {REPORT_TEMPLATE_FORMATTING_ACTIONS.map((action) => (
        <button
          key={action.key}
          type="button"
          onClick={() => onAction(action)}
          className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100"
        >
          {action.label}
        </button>
      ))}
    </div>
  );
}

function TemplateBlocksPreview({ blocks, emptyText = "Sem conteúdo." }) {
  if (!Array.isArray(blocks) || !blocks.length) {
    return <div className="text-sm text-slate-400">{emptyText}</div>;
  }

  return (
    <div className="space-y-1 text-slate-800">
      {blocks.map((block) => {
        if (block?.type === "blank") {
          return <div key={block.key} className="h-3" />;
        }

        if (block?.type === "rule") {
          return <div key={block.key} className="my-2 border-t border-slate-300" />;
        }

        return (
          <div
            key={block.key}
            className="whitespace-pre-wrap break-words"
            style={{ textAlign: block?.align || "left" }}
          >
            {(block?.segments || []).map((segment, index) => (
              <span
                key={`${block.key}-${index}`}
                style={{
                  fontWeight: segment?.bold ? 700 : 400,
                  fontStyle: segment?.italic ? "italic" : "normal",
                  textDecoration: segment?.underline ? "underline" : "none",
                  fontSize: `${Math.max(8, Math.min(22, Number(segment?.fontSize || block?.fontSize || 11)))}px`,
                  lineHeight: 1.45,
                }}
              >
                {segment?.text}
              </span>
            ))}
          </div>
        );
      })}
    </div>
  );
}

function buildPreviewRecord(sampleRow, selectedCategory = 1, templateName = "Modelo em edição") {
  const row = sampleRow || {};
  return {
    paciente: row?.paciente || "Paciente Exemplo",
    profissional: row?.profissional || "Profissional Exemplo",
    dataHoraAgendada: row?.dataHoraAgendada || "01/01/2026 08:00",
    dataHoraCriada: row?.dataHoraCriada || "31/12/2025 18:00",
    procedimento: row?.procedimento || "Procedimento Exemplo",
    convenio: row?.convenio || "Convênio Exemplo",
    plano: row?.plano || "Plano Exemplo",
    status: row?.status || "Agendado",
    statusSecundario: row?.statusSecundario || "",
    celular: row?.celular || "(11) 99999-0000",
    telefone: row?.telefone || "(11) 3333-0000",
    cidade: row?.cidade || "São Paulo",
    local: row?.local || "Unidade Principal",
    unidade: row?.unidade || "São Miguel",
    origemAgendamento: row?.origemAgendamento || "Amplimed",
    tipoAtendimento: row?.tipoAtendimento || "Consulta",
    valor: row?.valor || "0,00",
    recebido: row?.recebido || "Não",
    observacao: row?.observacao || "Observação de exemplo.",
    motivoBloqueio: row?.motivoBloqueio || "",
    motivoCancelamento: row?.motivoCancelamento || "",
    nomeAgendou: row?.nomeAgendou || "Equipe",
    tags: row?.tags || "Demanda Exemplo",
    codigoPaciente: row?.codigoPaciente || "00001",
    cpf: row?.cpf || "000.000.000-00",
    dataNascimento: row?.dataNascimento || "01/01/1990",
    entradaPaciente: row?.entradaPaciente || "",
    saidaPaciente: row?.saidaPaciente || "",
    entradaProfissional: row?.entradaProfissional || "",
    saidaProfissional: row?.saidaProfissional || "",
    sourceRow: row?.sourceRow || {},
    demandName: row?.demandName || "Demanda Exemplo",
    demandDescription: row?.demandDescription || "Descrição geral da demanda.",
    demandCidInf: row?.demandCidInf || "F90",
    demandCidAdult: row?.demandCidAdult || "F41",
    resolvedCid: row?.resolvedCid || row?.demandCidAdult || "F41",
    selectedCategory,
    categoryTitle: row?.categoryTitle || `Categoria ${selectedCategory}`,
    categoryContent:
      row?.categoryContent ||
      `Conteúdo de exemplo da categoria ${selectedCategory}. Você pode combinar texto livre, alinhamento, tamanhos e TAGS automáticas.`,
    _templateName: templateName,
  };
}

function TemplateRenderedPreview({ templateForm, previewRecord, selectedCategory }) {
  const context = {
    selectedCategory,
    generatedAt: new Date(),
    templateName: templateForm?.name || previewRecord?._templateName || "Modelo em edição",
    recordIndex: 0,
    recordCount: 1,
  };

  const headerBlocks = buildTemplateRenderBlocks(templateForm?.headerTemplate || "", previewRecord, context, {
    fontSize: 11,
    align: "left",
  });
  const bodyBlocks = buildTemplateRenderBlocks(templateForm?.bodyTemplate || "", previewRecord, context, {
    fontSize: 10.5,
    align: "left",
  });
  const footerBlocks = buildTemplateRenderBlocks(templateForm?.footerTemplate || "", previewRecord, context, {
    fontSize: 8.8,
    align: "center",
  });

  const renderMiniReport = (key) => (
    <div
      key={key}
      className="flex h-[430px] flex-col rounded-[20px] border border-slate-300 bg-white px-4 py-4 shadow-sm"
    >
      <div className="border-b border-slate-200 pb-3">
        {templateForm?.headerLogoDataUrl ? (
          <div className="mb-3">
            <img
              src={templateForm.headerLogoDataUrl}
              alt="Logo do relatório"
              className="max-h-14 w-auto max-w-[180px] object-contain"
            />
          </div>
        ) : null}

        <TemplateBlocksPreview blocks={headerBlocks} emptyText="Cabeçalho vazio." />
      </div>

      <div className="min-h-0 flex-1 overflow-hidden py-4">
        <TemplateBlocksPreview blocks={bodyBlocks} emptyText="Corpo vazio." />
      </div>

      <div className="border-t border-slate-200 pt-3">
        <TemplateBlocksPreview blocks={footerBlocks} emptyText="Rodapé vazio." />
      </div>
    </div>
  );

  return (
    <div className="rounded-[28px] border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 px-5 py-4">
        <div className="text-xs font-bold uppercase text-slate-500">Preview da página</div>
        <div className="mt-1 text-sm text-slate-500">
          O PDF sai em A4 paisagem, com 2 relatórios lado a lado. O preview agora mostra o cabeçalho sem a caixa lateral e com suporte à logo.
        </div>
      </div>

      <div className="px-5 py-5">
        <div className="rounded-[28px] border border-slate-200 bg-slate-100 p-4">
          <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
            {[1, 2].map((slotIndex) => renderMiniReport(slotIndex))}
          </div>
        </div>
      </div>
    </div>
  );
}


export default function AdminReportImportView({ showToast }) {
  const [activeTab, setActiveTab] = useState("import");

  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [result, setResult] = useState(null);
  const [templateError, setTemplateError] = useState(null);
  const [importSessionId, setImportSessionId] = useState("");
  const [expiresAt, setExpiresAt] = useState(null);

  const [selectedCategory, setSelectedCategory] = useState(1);
  const [selectedTemplateId, setSelectedTemplateId] = useState("");

  const [demands, setDemands] = useState([]);
  const [demandsLoading, setDemandsLoading] = useState(false);
  const [demandBusy, setDemandBusy] = useState(false);
  const [editingDemandId, setEditingDemandId] = useState("");
  const [demandForm, setDemandForm] = useState(createEmptyDemandForm());

  const [specialties, setSpecialties] = useState([]);
  const [specialtiesLoading, setSpecialtiesLoading] = useState(false);
  const [specialtyBusy, setSpecialtyBusy] = useState(false);
  const [editingSpecialtyId, setEditingSpecialtyId] = useState("");
  const [selectedSpecialtyId, setSelectedSpecialtyId] = useState("");
  const [specialtyForm, setSpecialtyForm] = useState(createEmptySpecialtyForm());

  const [specialtyDemands, setSpecialtyDemands] = useState([]);
  const [specialtyDemandsLoading, setSpecialtyDemandsLoading] = useState(false);
  const [specialtyDemandBusy, setSpecialtyDemandBusy] = useState(false);
  const [editingSpecialtyDemandId, setEditingSpecialtyDemandId] = useState("");
  const [specialtyDemandForm, setSpecialtyDemandForm] = useState(createEmptyDemandForm());

  const [templates, setTemplates] = useState([]);
  const [templatesLoading, setTemplatesLoading] = useState(false);
  const [templateBusy, setTemplateBusy] = useState(false);
  const [editingTemplateId, setEditingTemplateId] = useState("");
  const [templateForm, setTemplateForm] = useState(createEmptyTemplateForm());

  const previewColumns = useMemo(
    () => result?.template?.previewColumns || REPORT_IMPORT_TEMPLATE.previewColumns,
    [result]
  );

  const selectedTemplate = useMemo(
    () => templates.find((item) => String(item.id) === String(selectedTemplateId)) || null,
    [templates, selectedTemplateId]
  );

  const selectedSpecialty = useMemo(
    () => specialties.find((item) => String(item.id) === String(selectedSpecialtyId)) || null,
    [specialties, selectedSpecialtyId]
  );

  const specialtyDefaultDemandOptions = useMemo(
    () =>
      specialtyDemands.filter(
        (item) => item?.id && String(item?.name || "").trim()
      ),
    [specialtyDemands]
  );

  const loadSpecialties = useCallback(
    async (preferredId = "") => {
      setSpecialtiesLoading(true);
      try {
        const response = await adminFetch("/api/admin/report/specialties");
        const data = await response.json().catch(() => ({}));

        if (!response.ok || !data?.ok) {
          showToast?.(data?.error || "Falha ao carregar as Especialidades.", "error");
          return;
        }

        const items = Array.isArray(data?.items) ? data.items : [];
        setSpecialties(items);
        setSelectedSpecialtyId((current) => {
          const preferred = String(preferredId || editingSpecialtyId || current || "").trim();
          if (preferred && items.some((item) => String(item.id) === preferred)) {
            return preferred;
          }
          return String(items[0]?.id || "");
        });
      } catch (error) {
        console.error(error);
        showToast?.("Erro ao carregar o cadastro de Especialidades.", "error");
      } finally {
        setSpecialtiesLoading(false);
      }
    },
    [editingSpecialtyId, showToast]
  );

  const loadSpecialtyDemands = useCallback(
    async (specialtyId) => {
      const id = String(specialtyId || "").trim();
      if (!id) {
        setSpecialtyDemands([]);
        return;
      }

      setSpecialtyDemandsLoading(true);
      try {
        const response = await adminFetch(`/api/admin/report/specialties/${id}/demands`);
        const data = await response.json().catch(() => ({}));

        if (!response.ok || !data?.ok) {
          showToast?.(data?.error || "Falha ao carregar as Demandas da Especialidade.", "error");
          return;
        }

        setSpecialtyDemands(Array.isArray(data?.items) ? data.items : []);
      } catch (error) {
        console.error(error);
        showToast?.("Erro ao carregar as Demandas da Especialidade.", "error");
      } finally {
        setSpecialtyDemandsLoading(false);
      }
    },
    [showToast]
  );

  const loadDemands = useCallback(async () => {
    setDemandsLoading(true);
    try {
      const response = await adminFetch("/api/admin/report/demands");
      const data = await response.json().catch(() => ({}));

      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao carregar as Demandas.", "error");
        return;
      }

      setDemands(Array.isArray(data?.items) ? data.items : []);
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao carregar o cadastro de Demandas.", "error");
    } finally {
      setDemandsLoading(false);
    }
  }, [showToast]);

  const loadTemplates = useCallback(async () => {
    setTemplatesLoading(true);
    try {
      const response = await adminFetch("/api/admin/report/templates");
      const data = await response.json().catch(() => ({}));

      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao carregar os Modelos de Relatório.", "error");
        return;
      }

      const items = Array.isArray(data?.items) ? data.items : [];
      setTemplates(items);

      setSelectedTemplateId((current) => {
        if (current && items.some((item) => String(item.id) === String(current))) {
          return current;
        }
        return String(items.find((item) => item?.isActive)?.id || items[0]?.id || "");
      });
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao carregar os Modelos de Relatório.", "error");
    } finally {
      setTemplatesLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    loadDemands();
    loadSpecialties();
    loadTemplates();
  }, [loadDemands, loadSpecialties, loadTemplates]);

  useEffect(() => {
    if (!selectedSpecialtyId) {
      setSpecialtyDemands([]);
      setEditingSpecialtyDemandId("");
      setSpecialtyDemandForm(createEmptyDemandForm());
      return;
    }
    loadSpecialtyDemands(selectedSpecialtyId);
  }, [loadSpecialtyDemands, selectedSpecialtyId]);

  const handleFileChange = (event) => {
    const nextFile = event.target.files?.[0] || null;
    setFile(nextFile);
    setResult(null);
    setTemplateError(null);
    setImportSessionId("");
    setExpiresAt(null);
  };

  const handleResetImport = () => {
    setFile(null);
    setResult(null);
    setTemplateError(null);
    setImportSessionId("");
    setExpiresAt(null);
    const input = document.getElementById("report-import-file");
    if (input) input.value = "";
  };

  const appendCommonFormData = (formData) => {
    formData.append("selectedCategory", String(selectedCategory));
    if (selectedTemplateId) formData.append("templateId", String(selectedTemplateId));
  };

  const handleSubmitImport = async (event) => {
    event?.preventDefault?.();

    if (!file) {
      showToast?.("Selecione um arquivo .xlsx antes de importar.", "error");
      return;
    }

    setBusy(true);
    setResult(null);
    setTemplateError(null);
    setImportSessionId("");
    setExpiresAt(null);

    try {
      const formData = new FormData();
      formData.append("file", file);
      appendCommonFormData(formData);

      const response = await adminFetch("/api/admin/report/import", {
        method: "POST",
        body: formData,
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok || !data?.ok) {
        if (data?.code === "invalid-template-headers") {
          setTemplateError(buildTemplateErrorState(data));
          setResult(null);
          setImportSessionId("");
          setExpiresAt(null);
          showToast?.(data?.error || "A planilha não corresponde ao template esperado.", "error");
          return;
        }

        setTemplateError(null);
        setResult(null);
        setImportSessionId("");
        setExpiresAt(null);
        showToast?.(data?.error || "Falha ao analisar a planilha.", "error");
        return;
      }

      if (!String(data?.importSessionId || "").trim()) {
        setResult(null);
        setImportSessionId("");
        setExpiresAt(null);
        showToast?.("A análise foi concluída, mas a sessão congelada do preview não foi criada.", "error");
        return;
      }

      setTemplateError(null);
      setResult(data);
      setImportSessionId(String(data.importSessionId || "").trim());
      setExpiresAt(data?.expiresAt || null);
      showToast?.("Planilha analisada e preview congelado com a categoria e o modelo escolhidos para o lote.", "success");
    } catch (error) {
      console.error(error);
      setResult(null);
      setTemplateError(null);
      setImportSessionId("");
      setExpiresAt(null);
      showToast?.("Erro ao enviar a planilha para análise.", "error");
    } finally {
      setBusy(false);
    }
  };

  const handleGeneratePdf = async () => {
    if (!String(importSessionId || "").trim()) {
      showToast?.("Importe a planilha e gere um preview congelado antes de gerar o PDF.", "error");
      return;
    }

    if (!readyRows) {
      showToast?.("Nenhuma linha pronta para gerar PDF neste preview congelado.", "error");
      return;
    }

    setPdfBusy(true);
    try {
      const response = await adminFetch("/api/admin/report/pdf", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ importSessionId }),
      });

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));

        if (data?.code === "report-import-session-expired") {
          setImportSessionId("");
          setExpiresAt(null);
          showToast?.(data?.error || "A sessão de importação expirou. Importe a planilha novamente.", "error");
          return;
        }

        if (data?.code === "report-import-session-not-found" || data?.code === "report-import-session-forbidden") {
          setImportSessionId("");
          setExpiresAt(null);
          showToast?.(data?.error || "A sessão congelada do preview não está mais disponível. Importe novamente.", "error");
          return;
        }

        showToast?.(data?.error || "Falha ao gerar o PDF do lote.", "error");
        return;
      }

      const blob = await response.blob();
      const contentDisposition = response.headers.get("Content-Disposition") || "";
      const fileNameMatch = contentDisposition.match(/filename="([^"]+)"/i);
      const fileName = fileNameMatch?.[1] || `relatorios-categoria-${selectedCategory}.pdf`;

      const url = window.URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = fileName;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.URL.revokeObjectURL(url);

      const readyRowsCount = Number(response.headers.get("X-Report-Ready-Rows") || 0);
      const skippedRows = Number(response.headers.get("X-Report-Skipped-Rows") || 0);
      showToast?.(
        skippedRows
          ? `PDF gerado com ${readyRowsCount} linha(s) pronta(s). ${skippedRows} linha(s) foram puladas.`
          : "PDF gerado com sucesso a partir do preview congelado.",
        "success"
      );
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao gerar o PDF do lote.", "error");
    } finally {
      setPdfBusy(false);
    }
  };

  const handleDemandFieldChange = (field, value) => {
    setDemandForm((current) => ({ ...current, [field]: value }));
  };

  const handleCancelEditDemand = () => {
    setEditingDemandId("");
    setDemandForm(createEmptyDemandForm());
  };

  const handleEditDemand = (item) => {
    setActiveTab("demands");
    setEditingDemandId(String(item?.id || ""));
    setDemandForm(mapDemandToForm(item));
  };

  const handleDemandSubmit = async (event) => {
    event?.preventDefault?.();

    const payload = {
      ...demandForm,
      isActive: Boolean(demandForm.isActive),
    };

    if (!String(payload.name || "").trim()) {
      showToast?.("Informe o nome da Demanda.", "error");
      return;
    }

    setDemandBusy(true);
    try {
      const url = editingDemandId
        ? `/api/admin/report/demands/${editingDemandId}`
        : "/api/admin/report/demands";
      const method = editingDemandId ? "PATCH" : "POST";

      const response = await adminFetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao salvar a Demanda.", "error");
        return;
      }

      showToast?.(
        editingDemandId ? "Demanda atualizada com sucesso." : "Demanda cadastrada com sucesso.",
        "success"
      );

      await loadDemands();
      handleCancelEditDemand();
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao salvar a Demanda.", "error");
    } finally {
      setDemandBusy(false);
    }
  };

  const handleToggleDemandActive = async (item) => {
    if (!item?.id) return;

    setDemandBusy(true);
    try {
      const response = await adminFetch(`/api/admin/report/demands/${item.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !item.isActive }),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao atualizar a Demanda.", "error");
        return;
      }

      await loadDemands();
      showToast?.(
        item.isActive ? "Demanda inativada com sucesso." : "Demanda ativada com sucesso.",
        "success"
      );
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao atualizar a Demanda.", "error");
    } finally {
      setDemandBusy(false);
    }
  };

  const handleDeleteDemand = async (item) => {
    if (!item?.id) return;
    const confirmed = window.confirm(`Excluir a Demanda "${item.name}"?`);
    if (!confirmed) return;

    setDemandBusy(true);
    try {
      const response = await adminFetch(`/api/admin/report/demands/${item.id}`, {
        method: "DELETE",
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao excluir a Demanda.", "error");
        return;
      }

      if (String(editingDemandId) === String(item.id)) {
        handleCancelEditDemand();
      }

      await loadDemands();
      showToast?.("Demanda excluída com sucesso.", "success");
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao excluir a Demanda.", "error");
    } finally {
      setDemandBusy(false);
    }
  };



  const handleSpecialtyFieldChange = (field, value) => {
    setSpecialtyForm((current) => ({ ...current, [field]: value }));
  };

  const handleCancelEditSpecialty = () => {
    setEditingSpecialtyId("");
    setSpecialtyForm(createEmptySpecialtyForm());
  };

  const handleSelectSpecialty = (item) => {
    const specialtyId = String(item?.id || "").trim();
    if (!specialtyId) return;
    setSelectedSpecialtyId(specialtyId);
    setEditingSpecialtyDemandId("");
    setSpecialtyDemandForm(createEmptyDemandForm());
  };

  const handleEditSpecialty = (item) => {
    setActiveTab("demands");
    setEditingSpecialtyId(String(item?.id || ""));
    setSelectedSpecialtyId(String(item?.id || ""));
    setSpecialtyForm(mapSpecialtyToForm(item));
  };

  const handleSpecialtySubmit = async (event) => {
    event?.preventDefault?.();

    const payload = {
      ...specialtyForm,
      isActive: Boolean(specialtyForm.isActive),
      defaultDemandId:
        specialtyForm.demandSourceMode === REPORT_SPECIALTY_DEMAND_SOURCE_MODES.SYSTEM_DEFAULT
          ? String(specialtyForm.defaultDemandId || "").trim()
          : "",
    };

    if (!String(payload.name || "").trim()) {
      showToast?.("Informe o nome da Especialidade.", "error");
      return;
    }

    if (
      payload.demandSourceMode === REPORT_SPECIALTY_DEMAND_SOURCE_MODES.SYSTEM_DEFAULT &&
      !payload.defaultDemandId
    ) {
      showToast?.("Escolha a Demanda padrão da Especialidade.", "error");
      return;
    }

    setSpecialtyBusy(true);
    try {
      const url = editingSpecialtyId
        ? `/api/admin/report/specialties/${editingSpecialtyId}`
        : "/api/admin/report/specialties";
      const method = editingSpecialtyId ? "PATCH" : "POST";

      const response = await adminFetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao salvar a Especialidade.", "error");
        return;
      }

      const specialtyId = String(data?.id || editingSpecialtyId || "").trim();
      await loadSpecialties(specialtyId);
      if (specialtyId) {
        setSelectedSpecialtyId(specialtyId);
        await loadSpecialtyDemands(specialtyId);
      }
      handleCancelEditSpecialty();
      showToast?.(
        editingSpecialtyId
          ? "Especialidade atualizada com sucesso."
          : "Especialidade cadastrada com sucesso.",
        "success"
      );
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao salvar a Especialidade.", "error");
    } finally {
      setSpecialtyBusy(false);
    }
  };

  const handleToggleSpecialtyActive = async (item) => {
    if (!item?.id) return;

    setSpecialtyBusy(true);
    try {
      const response = await adminFetch(`/api/admin/report/specialties/${item.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !item.isActive }),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao atualizar a Especialidade.", "error");
        return;
      }

      await loadSpecialties(item.id);
      showToast?.(
        item.isActive ? "Especialidade inativada com sucesso." : "Especialidade ativada com sucesso.",
        "success"
      );
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao atualizar a Especialidade.", "error");
    } finally {
      setSpecialtyBusy(false);
    }
  };

  const handleDeleteSpecialty = async (item) => {
    if (!item?.id) return;
    const confirmed = window.confirm(`Excluir a Especialidade "${item.name}"?`);
    if (!confirmed) return;

    setSpecialtyBusy(true);
    try {
      const response = await adminFetch(`/api/admin/report/specialties/${item.id}`, {
        method: "DELETE",
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao excluir a Especialidade.", "error");
        return;
      }

      if (String(editingSpecialtyId) === String(item.id)) {
        handleCancelEditSpecialty();
      }
      if (String(selectedSpecialtyId) === String(item.id)) {
        setSelectedSpecialtyId("");
        setSpecialtyDemands([]);
        setEditingSpecialtyDemandId("");
        setSpecialtyDemandForm(createEmptyDemandForm());
      }

      await loadSpecialties();
      showToast?.("Especialidade excluída com sucesso.", "success");
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao excluir a Especialidade.", "error");
    } finally {
      setSpecialtyBusy(false);
    }
  };

  const handleSpecialtyDemandFieldChange = (field, value) => {
    setSpecialtyDemandForm((current) => ({ ...current, [field]: value }));
  };

  const handleCancelEditSpecialtyDemand = () => {
    setEditingSpecialtyDemandId("");
    setSpecialtyDemandForm(createEmptyDemandForm());
  };

  const handleEditSpecialtyDemand = (item) => {
    setEditingSpecialtyDemandId(String(item?.id || ""));
    setSpecialtyDemandForm(mapDemandToForm(item));
  };

  const handleSpecialtyDemandSubmit = async (event) => {
    event?.preventDefault?.();

    if (!selectedSpecialtyId) {
      showToast?.("Escolha uma Especialidade antes de cadastrar a Demanda.", "error");
      return;
    }

    const payload = {
      ...specialtyDemandForm,
      isActive: Boolean(specialtyDemandForm.isActive),
    };

    if (!String(payload.name || "").trim()) {
      showToast?.("Informe o nome da Demanda.", "error");
      return;
    }

    setSpecialtyDemandBusy(true);
    try {
      const url = editingSpecialtyDemandId
        ? `/api/admin/report/specialties/${selectedSpecialtyId}/demands/${editingSpecialtyDemandId}`
        : `/api/admin/report/specialties/${selectedSpecialtyId}/demands`;
      const method = editingSpecialtyDemandId ? "PATCH" : "POST";

      const response = await adminFetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao salvar a Demanda da Especialidade.", "error");
        return;
      }

      await loadSpecialtyDemands(selectedSpecialtyId);
      await loadSpecialties(selectedSpecialtyId);
      handleCancelEditSpecialtyDemand();
      showToast?.(
        editingSpecialtyDemandId
          ? "Demanda da Especialidade atualizada com sucesso."
          : "Demanda da Especialidade cadastrada com sucesso.",
        "success"
      );
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao salvar a Demanda da Especialidade.", "error");
    } finally {
      setSpecialtyDemandBusy(false);
    }
  };

  const handleToggleSpecialtyDemandActive = async (item) => {
    if (!selectedSpecialtyId || !item?.id) return;

    setSpecialtyDemandBusy(true);
    try {
      const response = await adminFetch(`/api/admin/report/specialties/${selectedSpecialtyId}/demands/${item.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !item.isActive }),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao atualizar a Demanda da Especialidade.", "error");
        return;
      }

      await loadSpecialtyDemands(selectedSpecialtyId);
      await loadSpecialties(selectedSpecialtyId);
      showToast?.(
        item.isActive
          ? "Demanda da Especialidade inativada com sucesso."
          : "Demanda da Especialidade ativada com sucesso.",
        "success"
      );
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao atualizar a Demanda da Especialidade.", "error");
    } finally {
      setSpecialtyDemandBusy(false);
    }
  };

  const handleDeleteSpecialtyDemand = async (item) => {
    if (!selectedSpecialtyId || !item?.id) return;
    const confirmed = window.confirm(`Excluir a Demanda "${item.name}" da Especialidade selecionada?`);
    if (!confirmed) return;

    setSpecialtyDemandBusy(true);
    try {
      const response = await adminFetch(`/api/admin/report/specialties/${selectedSpecialtyId}/demands/${item.id}`, {
        method: "DELETE",
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao excluir a Demanda da Especialidade.", "error");
        return;
      }

      if (String(editingSpecialtyDemandId) === String(item.id)) {
        handleCancelEditSpecialtyDemand();
      }

      await loadSpecialtyDemands(selectedSpecialtyId);
      await loadSpecialties(selectedSpecialtyId);
      showToast?.("Demanda da Especialidade excluída com sucesso.", "success");
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao excluir a Demanda da Especialidade.", "error");
    } finally {
      setSpecialtyDemandBusy(false);
    }
  };

  const handleSetDefaultDemandForSpecialty = async (item) => {
    if (!selectedSpecialty?.id || !item?.id) return;

    setSpecialtyBusy(true);
    try {
      const response = await adminFetch(`/api/admin/report/specialties/${selectedSpecialty.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          demandSourceMode: selectedSpecialty.demandSourceMode,
          defaultDemandId: item.id,
        }),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao definir a Demanda padrão.", "error");
        return;
      }

      await loadSpecialties(selectedSpecialty.id);
      if (String(editingSpecialtyId) === String(selectedSpecialty.id)) {
        setSpecialtyForm((current) => ({ ...current, defaultDemandId: item.id }));
      }
      showToast?.("Demanda padrão definida com sucesso.", "success");
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao definir a Demanda padrão.", "error");
    } finally {
      setSpecialtyBusy(false);
    }
  };

  const headerTemplateRef = useRef(null);
  const bodyTemplateRef = useRef(null);
  const footerTemplateRef = useRef(null);
  const [activeTemplateArea, setActiveTemplateArea] = useState("bodyTemplate");

  const getTemplateAreaRef = useCallback((field) => {
    const refs = {
      headerTemplate: headerTemplateRef,
      bodyTemplate: bodyTemplateRef,
      footerTemplate: footerTemplateRef,
    };
    return refs[field]?.current || null;
  }, []);

  const handleTemplateFieldChange = (field, value) => {
    setTemplateForm((current) => ({ ...current, [field]: value }));
  };

  const handleTemplateTextChange = (field, value) => {
    setTemplateForm((current) => ({ ...current, [field]: value }));
  };

  const handleTemplateLogoUpload = async (event) => {
    const nextFile = event.target.files?.[0] || null;
    event.target.value = "";

    if (!nextFile) return;

    try {
      const dataUrl = await readLogoAsJpegDataUrl(nextFile);
      if (dataUrl.length > REPORT_TEMPLATE_LOGO_MAX_DATA_URL_LENGTH) {
        showToast?.("A logo ficou grande demais. Tente uma imagem menor ou mais simples.", "error");
        return;
      }

      setTemplateForm((current) => ({ ...current, headerLogoDataUrl: dataUrl }));
      showToast?.("Logo preparada e vinculada ao cabeçalho do modelo.", "success");
    } catch (error) {
      console.error(error);
      showToast?.(error?.message || "Não foi possível carregar a logo.", "error");
    }
  };

  const handleRemoveTemplateLogo = () => {
    setTemplateForm((current) => ({ ...current, headerLogoDataUrl: "" }));
  };

  const handleCancelEditTemplate = () => {
    setEditingTemplateId("");
    setTemplateForm(createEmptyTemplateForm());
    setActiveTemplateArea("bodyTemplate");
  };

  const handleEditTemplate = (item) => {
    setActiveTab("templates");
    setEditingTemplateId(String(item?.id || ""));
    setTemplateForm(mapTemplateToForm(item));
    setActiveTemplateArea("bodyTemplate");
  };

  const updateTemplateFieldSelection = useCallback(
    (field, transformer) => {
      const ref = getTemplateAreaRef(field);
      const currentValue = String(templateForm?.[field] || "");
      const start = ref && typeof ref.selectionStart === "number" ? ref.selectionStart : currentValue.length;
      const end = ref && typeof ref.selectionEnd === "number" ? ref.selectionEnd : currentValue.length;

      const result = transformer(currentValue, start, end);
      if (!result || typeof result.value !== "string") return;

      handleTemplateTextChange(field, result.value);

      if (!ref) return;
      window.requestAnimationFrame(() => {
        ref.focus();
        if (typeof result.selectionStart === "number" && typeof result.selectionEnd === "number") {
          ref.setSelectionRange(result.selectionStart, result.selectionEnd);
        }
      });
    },
    [getTemplateAreaRef, templateForm]
  );

  const handleInsertTemplateTag = (tag, preferredField = "") => {
    const field = preferredField || activeTemplateArea || "bodyTemplate";
    updateTemplateFieldSelection(field, (currentValue, start, end) => {
      const nextValue = `${currentValue.slice(0, start)}${tag}${currentValue.slice(end)}`;
      const nextCursor = start + tag.length;
      return {
        value: nextValue,
        selectionStart: nextCursor,
        selectionEnd: nextCursor,
      };
    });
  };

  const handleTemplateFormattingAction = useCallback(
    (field, action) => {
      if (!field || !action) return;

      const placeholderMap = {
        title: "TÍTULO",
        subtitle: "SUBTÍTULO",
      };

      if (action.type === "insert" || action.type === "lineSnippet") {
        const snippet = String(action.snippet || "");
        updateTemplateFieldSelection(field, (currentValue, start, end) => {
          const prefix = start > 0 && currentValue[start - 1] !== "\n" ? "\n" : "";
          const suffix = end < currentValue.length && currentValue[end] !== "\n" ? "\n" : "";
          const insertion = `${prefix}${snippet}${suffix}`;
          const nextValue = `${currentValue.slice(0, start)}${insertion}${currentValue.slice(end)}`;
          const nextCursor = start + insertion.length;
          return {
            value: nextValue,
            selectionStart: nextCursor,
            selectionEnd: nextCursor,
          };
        });
        return;
      }

      if (action.type === "wrap") {
        updateTemplateFieldSelection(field, (currentValue, start, end) => {
          const selectedText = currentValue.slice(start, end) || placeholderMap[action.key] || "texto";
          const openTag = String(action.open || "");
          const closeTag = String(action.close || "");
          const wrapped = `${openTag}${selectedText}${closeTag}`;
          return {
            value: `${currentValue.slice(0, start)}${wrapped}${currentValue.slice(end)}`,
            selectionStart: start + openTag.length,
            selectionEnd: start + openTag.length + selectedText.length,
          };
        });
        return;
      }

      if (action.type === "lineWrap") {
        updateTemplateFieldSelection(field, (currentValue, start, end) => {
          const lineStart = currentValue.lastIndexOf("\n", Math.max(0, start - 1)) + 1;
          const lineEndCandidate = currentValue.indexOf("\n", end);
          const lineEnd = lineEndCandidate === -1 ? currentValue.length : lineEndCandidate;
          const selectedText = currentValue.slice(lineStart, lineEnd) || "texto";
          const wrapped = selectedText
            .split("\n")
            .map((line) => {
              if (!line.trim()) return line;
              return `${action.open}${line}${action.close}`;
            })
            .join("\n");

          return {
            value: `${currentValue.slice(0, lineStart)}${wrapped}${currentValue.slice(lineEnd)}`,
            selectionStart: lineStart,
            selectionEnd: lineStart + wrapped.length,
          };
        });
      }
    },
    [updateTemplateFieldSelection]
  );
  const templatePreviewRecord = useMemo(
    () => buildPreviewRecord(result?.previewRows?.[0], selectedCategory, templateForm?.name || "Modelo em edição"),
    [result, selectedCategory, templateForm?.name]
  );

  const templateUnknownTokens = useMemo(() => {
    return {
      header: findUnknownTemplateTokens(templateForm?.headerTemplate || ""),
      body: findUnknownTemplateTokens(templateForm?.bodyTemplate || ""),
      footer: findUnknownTemplateTokens(templateForm?.footerTemplate || ""),
    };
  }, [templateForm?.headerTemplate, templateForm?.bodyTemplate, templateForm?.footerTemplate]);

  const handleTemplateSubmit = async (event) => {
    event?.preventDefault?.();

    if (!String(templateForm.name || "").trim()) {
      showToast?.("Informe o nome do Modelo de Relatório.", "error");
      return;
    }

    setTemplateBusy(true);
    try {
      const payload = {
        name: templateForm.name,
        description: templateForm.description,
        isActive: Boolean(templateForm.isActive),
        editorMode: "tagTemplate",
        headerLogoDataUrl: templateForm.headerLogoDataUrl || "",
        headerTemplate: templateForm.headerTemplate,
        bodyTemplate: templateForm.bodyTemplate,
        footerTemplate: templateForm.footerTemplate,
      };

      const url = editingTemplateId
        ? `/api/admin/report/templates/${editingTemplateId}`
        : "/api/admin/report/templates";
      const method = editingTemplateId ? "PATCH" : "POST";

      const response = await adminFetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao salvar o Modelo de Relatório.", "error");
        return;
      }

      showToast?.(
        editingTemplateId ? "Modelo atualizado com sucesso." : "Modelo cadastrado com sucesso.",
        "success"
      );

      await loadTemplates();
      handleCancelEditTemplate();
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao salvar o Modelo de Relatório.", "error");
    } finally {
      setTemplateBusy(false);
    }
  };

  const handleToggleTemplateActive = async (item) => {
    if (!item?.id) return;

    setTemplateBusy(true);
    try {
      const response = await adminFetch(`/api/admin/report/templates/${item.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: true }),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao ativar o modelo.", "error");
        return;
      }

      await loadTemplates();
      setSelectedTemplateId(String(item.id));
      showToast?.("Modelo ativado para uso no lote.", "success");
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao ativar o modelo.", "error");
    } finally {
      setTemplateBusy(false);
    }
  };

  const handleDeleteTemplate = async (item) => {
    if (!item?.id) return;
    const confirmed = window.confirm(`Excluir o Modelo "${item.name}"?`);
    if (!confirmed) return;

    setTemplateBusy(true);
    try {
      const response = await adminFetch(`/api/admin/report/templates/${item.id}`, {
        method: "DELETE",
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data?.ok) {
        showToast?.(data?.error || "Falha ao excluir o modelo.", "error");
        return;
      }

      if (String(editingTemplateId) === String(item.id)) {
        handleCancelEditTemplate();
      }

      await loadTemplates();
      setSelectedTemplateId((current) => (String(current) === String(item.id) ? "" : current));
      showToast?.("Modelo excluído com sucesso.", "success");
    } catch (error) {
      console.error(error);
      showToast?.("Erro ao excluir o modelo.", "error");
    } finally {
      setTemplateBusy(false);
    }
  };

  const readyRows = Number(result?.matchSummary?.ready || 0);
  const invalidRows = result
    ? Math.max(0, Number(result?.summary?.totalRows || 0) - readyRows)
    : 0;
  const mismatchSummaryItems = useMemo(
    () => [
      { key: "missingSpecialty", label: "Especialidade em branco", value: Number(result?.matchSummary?.missingSpecialty || 0) },
      { key: "specialtyNotFound", label: "Especialidade não encontrada", value: Number(result?.matchSummary?.specialtyNotFound || 0) },
      { key: "inactiveSpecialty", label: "Especialidade inativa", value: Number(result?.matchSummary?.inactiveSpecialty || 0) },
      { key: "psychologyMissingDemand", label: "Psicologia sem Demanda", value: Number(result?.matchSummary?.psychologyMissingDemand || 0) },
      { key: "psychologyDemandNotFound", label: "Demanda da Psicologia não encontrada", value: Number(result?.matchSummary?.psychologyDemandNotFound || 0) },
      { key: "specialtyWithoutDefaultDemand", label: "Sem Demanda padrão", value: Number(result?.matchSummary?.specialtyWithoutDefaultDemand || 0) },
      { key: "inactiveDemand", label: "Demanda inativa", value: Number(result?.matchSummary?.inactiveDemand || 0) },
      { key: "missingCategory", label: "Categoria vazia", value: Number(result?.matchSummary?.missingCategory || 0) },
    ].filter((item) => item.value > 0),
    [result]
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <a
            href="/admin"
            className="inline-flex items-center gap-2 text-sm text-slate-500 hover:text-slate-700 transition-colors"
          >
            <ArrowLeft size={16} />
            Voltar ao painel admin
          </a>

          <div className="mt-3 flex items-center gap-3">
            <div className="h-12 w-12 rounded-2xl bg-violet-50 text-violet-600 flex items-center justify-center border border-violet-100">
              <FileSpreadsheet size={24} />
            </div>

            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-900">Relatórios • Importação, Especialidades e Modelos</h1>
              <p className="text-sm text-slate-500">
                Monte o modelo do PDF, cadastre Especialidades/Demandas e gere um preview congelado. Psicologia usa Demanda do arquivo; Nutrição/Fonoaudiologia usam a Demanda padrão do sistema.
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            type="button"
            variant={activeTab === "import" ? "primary" : "secondary"}
            onClick={() => setActiveTab("import")}
            icon={Upload}
          >
            Importação
          </Button>
          <Button
            type="button"
            variant={activeTab === "demands" ? "primary" : "secondary"}
            onClick={() => setActiveTab("demands")}
            icon={Tags}
          >
            Especialidades / Demandas
          </Button>
          <Button
            type="button"
            variant={activeTab === "templates" ? "primary" : "secondary"}
            onClick={() => setActiveTab("templates")}
            icon={Layers3}
          >
            Modelos
          </Button>
        </div>
      </div>

      {activeTab === "import" && (
        <div className="space-y-6">
          <div className="grid gap-6 xl:grid-cols-[minmax(0,1.2fr)_minmax(320px,0.8fr)]">
            <div className="space-y-6">
              <Card title="Importar planilha e validar lote">
                <form className="space-y-6" onSubmit={handleSubmitImport}>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <label className="text-xs font-bold text-slate-500 uppercase ml-1">Categoria do lote</label>
                      <select
                        className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                        value={selectedCategory}
                        onChange={(event) => {
                          setSelectedCategory(Number(event.target.value));
                          setResult(null);
                          setTemplateError(null);
                          setImportSessionId("");
                          setExpiresAt(null);
                        }}
                      >
                        {REPORT_DEMAND_CATEGORY_OPTIONS.map((categoryNumber) => (
                          <option key={categoryNumber} value={categoryNumber}>
                            Categoria {categoryNumber}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-500 uppercase ml-1">Modelo do relatório</label>
                      <select
                        className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                        value={selectedTemplateId}
                        onChange={(event) => {
                          setSelectedTemplateId(event.target.value);
                          setResult(null);
                          setTemplateError(null);
                          setImportSessionId("");
                          setExpiresAt(null);
                        }}
                      >
                        <option value="">Sem modelo ativo (usar padrão)</option>
                        {templates.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.name}{item.isActive ? " • ativo" : ""}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="rounded-2xl border border-dashed border-violet-200 bg-violet-50/40 p-5">
                    <div className="text-sm font-semibold text-slate-800">Modelo aplicado ao lote</div>
                    <div className="mt-1 text-sm text-slate-600">
                      {selectedTemplate
                        ? `${selectedTemplate.name} • ${buildTemplateSummary(selectedTemplate)}`
                        : "Nenhum modelo selecionado; o PDF usa o layout padrão seguro do módulo."}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-500 uppercase ml-1">Arquivo .xlsx</label>
                    <input
                      id="report-import-file"
                      type="file"
                      accept=".xlsx"
                      className="mt-2 block w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 file:mr-4 file:rounded-lg file:border-0 file:bg-violet-50 file:px-3 file:py-2 file:text-sm file:font-medium file:text-violet-700 hover:file:bg-violet-100"
                      onChange={handleFileChange}
                    />
                    <div className="mt-2 text-xs text-slate-500">
                      Estrutura esperada: {REPORT_IMPORT_TEMPLATE.sourceLabel} • {REPORT_IMPORT_TEMPLATE.requiredHeaders.length} colunas.
                    </div>
                  </div>

                  {file && (
                    <div className="rounded-xl border border-emerald-100 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                      <div className="font-semibold">{file.name}</div>
                      <div className="text-emerald-600">{formatBytes(file.size)}</div>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-3">
                    <Button type="submit" disabled={busy} icon={Upload}>
                      {busy ? "Lendo planilha..." : "Importar e validar"}
                    </Button>

                    <Button type="button" variant="secondary" onClick={handleResetImport} disabled={busy} icon={RefreshCcw}>
                      Limpar
                    </Button>

                    <Button
                      type="button"
                      variant="success"
                      onClick={handleGeneratePdf}
                      disabled={pdfBusy || !importSessionId || readyRows === 0}
                      icon={FileDown}
                    >
                      {pdfBusy ? "Gerando PDF..." : "Gerar PDF"}
                    </Button>
                  </div>
                </form>
              </Card>
            </div>

            <div className="space-y-6">
              <Card title="Modelos cadastrados para o lote">
                <div className="space-y-3">
                  {templatesLoading && (
                    <div className="rounded-xl border border-slate-100 bg-slate-50 px-4 py-3 text-sm text-slate-500">
                      Carregando modelos...
                    </div>
                  )}

                  {!templatesLoading && !templates.length && (
                    <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-500">
                      Nenhum modelo cadastrado ainda. Vá para a aba <b>Modelos</b> para montar o relatório.
                    </div>
                  )}

                  {templates.map((item) => (
                    <div key={item.id} className="rounded-2xl border border-slate-100 p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <div className="text-sm font-semibold text-slate-900">{item.name}</div>
                            {item.isActive && <Badge status="confirmed" text="Ativo" />}
                          </div>
                          <div className="mt-1 text-xs text-slate-500">{buildTemplateSummary(item)}</div>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          <Button
                            type="button"
                            variant="secondary"
                            onClick={() => {
                              setSelectedTemplateId(String(item.id));
                              setResult(null);
                              setTemplateError(null);
                              setImportSessionId("");
                              setExpiresAt(null);
                            }}
                          >
                            Usar no lote
                          </Button>
                          <Button type="button" variant="secondary" onClick={() => handleEditTemplate(item)} icon={PencilLine}>
                            Editar
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card title="Especialidades / Demandas prontas para uso">
                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                      <div className="text-sm font-semibold text-slate-800">Especialidades carregadas</div>
                      <div className="mt-1 text-3xl font-bold text-slate-900">
                        {specialtiesLoading ? "..." : specialties.length}
                      </div>
                      <div className="mt-1 text-sm text-slate-500">
                        Base principal para validar a coluna <b>Especialidade</b>.
                      </div>
                    </div>

                    <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                      <div className="text-sm font-semibold text-slate-800">Demandas carregadas</div>
                      <div className="mt-1 text-3xl font-bold text-slate-900">
                        {specialtiesLoading ? "..." : specialtyDemands.length}
                      </div>
                      <div className="mt-1 text-sm text-slate-500">
                        Demandas da Especialidade selecionada no cadastro.
                      </div>
                    </div>
                  </div>

                  <div className="rounded-xl border border-violet-100 bg-violet-50 px-4 py-3 text-sm text-violet-800">
                    Categoria escolhida para o lote: <b>Categoria {selectedCategory}</b>
                  </div>

                  <div className="text-sm text-slate-500 leading-relaxed">
                    Dica operacional: valide primeiro a <b>Especialidade</b>. Em <b>Psicologia</b>, a Demanda vem da coluna <b>Demanda</b> com fallback em <b>Tags</b>. Em <b>Nutrição</b> e <b>Fonoaudiologia</b>, a Demanda usada vem do sistema. <b>CID</b> e <b>Categoria</b> sempre vêm do cadastro da Demanda.
                  </div>
                </div>
              </Card>
            </div>
          </div>

          <Card title="Resumo operacional do lote">
            <div className="grid gap-4 md:grid-cols-3">
              <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
                <div className="text-xs font-bold uppercase text-slate-500">Especialidades</div>
                <div className="mt-2 text-3xl font-bold text-slate-900">{specialtiesLoading ? "..." : specialties.length}</div>
                <div className="mt-1 text-sm text-slate-500">Cadastradas para validar a coluna Especialidade.</div>
              </div>

              <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-4">
                <div className="text-xs font-bold uppercase text-emerald-700">Linhas prontas</div>
                <div className="mt-2 text-3xl font-bold text-emerald-900">{readyRows}</div>
                <div className="mt-1 text-sm text-emerald-700">Válidas para o PDF após validar Especialidade e Demanda.</div>
              </div>

              <div className="rounded-2xl border border-amber-100 bg-amber-50 p-4">
                <div className="text-xs font-bold uppercase text-amber-700">Linhas com atenção</div>
                <div className="mt-2 text-3xl font-bold text-amber-900">{invalidRows}</div>
                <div className="mt-1 text-sm text-amber-700">Especialidade inválida, Demanda inconsistente, categoria vazia ou cadastro inativo.</div>
              </div>
            </div>

            {result?.selectedTemplate && (
              <div className="mt-4 rounded-xl border border-violet-100 bg-violet-50 px-4 py-3 text-sm text-violet-800">
                Modelo aplicado na análise: <b>{result.selectedTemplate.name}</b>
              </div>
            )}

            {!!mismatchSummaryItems.length && (
              <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                {mismatchSummaryItems.map((item) => (
                  <div key={item.key} className="rounded-xl border border-amber-100 bg-amber-50 px-4 py-3">
                    <div className="text-xs font-bold uppercase text-amber-700">{item.label}</div>
                    <div className="mt-2 text-2xl font-bold text-amber-900">{item.value}</div>
                  </div>
                ))}
              </div>
            )}
          </Card>

          {templateError && (
            <Card title="Template inválido">
              <div className="space-y-4">
                <div className="rounded-xl border border-rose-100 bg-rose-50 px-4 py-3 text-sm text-rose-700">
                  {templateError.error}
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                    <div className="text-xs font-bold uppercase text-slate-500">Colunas esperadas</div>
                    <div className="mt-2 text-2xl font-bold text-slate-900">{templateError.expectedCount || "—"}</div>
                  </div>
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                    <div className="text-xs font-bold uppercase text-slate-500">Colunas recebidas</div>
                    <div className="mt-2 text-2xl font-bold text-slate-900">{templateError.receivedCount || "—"}</div>
                  </div>
                </div>

                {!!templateError.missingHeaders?.length && (
                  <div className="rounded-xl border border-rose-100 bg-rose-50 px-4 py-3">
                    <div className="text-xs font-bold uppercase text-rose-700">Cabeçalhos faltantes</div>
                    <div className="mt-2 text-sm text-rose-800">{templateError.missingHeaders.join(" • ")}</div>
                  </div>
                )}

                {!!templateError.extraHeaders?.length && (
                  <div className="rounded-xl border border-amber-100 bg-amber-50 px-4 py-3">
                    <div className="text-xs font-bold uppercase text-amber-700">Cabeçalhos extras</div>
                    <div className="mt-2 text-sm text-amber-800">{templateError.extraHeaders.join(" • ")}</div>
                  </div>
                )}
              </div>
            </Card>
          )}

          {result && (
            <Card title="Preview da validação">
              <div className="space-y-4">
                {importSessionId && (
                  <div className="rounded-xl border border-violet-100 bg-violet-50 px-4 py-3 text-sm text-violet-800">
                    <div className="font-semibold">Preview congelado</div>
                    <div className="mt-1">Sessão: <b>{String(importSessionId).slice(0, 8)}</b></div>
                    <div className="mt-1">Válido até: <b>{formatSessionExpiry(expiresAt)}</b></div>
                    <div className="mt-2 text-violet-700">O PDF será gerado com base neste preview congelado.</div>
                  </div>
                )}

                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                    <div className="text-xs font-bold uppercase text-slate-500">Linhas totais</div>
                    <div className="mt-2 text-2xl font-bold text-slate-900">{result?.summary?.totalRows || 0}</div>
                  </div>
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                    <div className="text-xs font-bold uppercase text-slate-500">Profissionais</div>
                    <div className="mt-2 text-2xl font-bold text-slate-900">{result?.summary?.professionals || 0}</div>
                  </div>
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                    <div className="text-xs font-bold uppercase text-slate-500">Aba lida</div>
                    <div className="mt-2 text-sm font-semibold text-slate-900">{result?.workbook?.sheetName || "—"}</div>
                  </div>
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                    <div className="text-xs font-bold uppercase text-slate-500">Importado em</div>
                    <div className="mt-2 text-sm font-semibold text-slate-900">
                      {result?.importedAt ? new Date(result.importedAt).toLocaleString("pt-BR") : "—"}
                    </div>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="min-w-full text-sm">
                    <thead>
                      <tr className="text-left text-slate-500 border-b border-slate-100">
                        {previewColumns.map((column) => (
                          <th key={column} className="px-3 py-2 font-semibold">{column}</th>
                        ))}
                        <th className="px-3 py-2 font-semibold">Especialidade</th>
                        <th className="px-3 py-2 font-semibold">Demanda usada</th>
                        <th className="px-3 py-2 font-semibold">Origem da Demanda</th>
                        <th className="px-3 py-2 font-semibold">CID resolvido</th>
                        <th className="px-3 py-2 font-semibold">Categoria aplicada</th>
                        <th className="px-3 py-2 font-semibold">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(result?.previewRows || []).map((row) => {
                        const badge = categoryStatusToBadge(row?.categoryStatus);
                        return (
                          <tr key={`${row.rowIndex}-${row.tags}-${row.paciente}`} className="border-b border-slate-50 align-top">
                            {previewColumns.map((column) => (
                              <td key={`${row.rowIndex}-${column}`} className="px-3 py-3 text-slate-700">
                                {row?.sourceRow?.[column] || "—"}
                              </td>
                            ))}
                            <td className="px-3 py-3 text-slate-700">{row?.specialtyName || row?.especialidade || "—"}</td>
                            <td className="px-3 py-3 text-slate-700">{row?.demandName || "—"}</td>
                            <td className="px-3 py-3 text-slate-700">
                              {row?.demandSourceUsed === "system_default"
                                ? "Sistema (Demanda padrão)"
                                : row?.demandSourceUsed === "excel"
                                  ? "Arquivo (Demanda/Tags)"
                                  : "—"}
                            </td>
                            <td className="px-3 py-3 text-slate-700">{row?.resolvedCid || "—"}</td>
                            <td className="px-3 py-3 text-slate-700">
                              {row?.categoryTitle || `Categoria ${selectedCategory}`}
                            </td>
                            <td className="px-3 py-3">
                              <Badge status={badge.status} text={badge.text} />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {!!result?.assumptions?.length && (
                  <div className="rounded-xl border border-slate-100 bg-slate-50 px-4 py-3 text-sm text-slate-600 space-y-1">
                    {result.assumptions.map((assumption, index) => (
                      <div key={`${index}-${assumption}`}>• {assumption}</div>
                    ))}
                  </div>
                )}
              </div>
            </Card>
          )}
        </div>
      )}


{activeTab === "demands" && (
        <div className="grid gap-6 xl:grid-cols-[minmax(0,0.9fr)_minmax(380px,1.1fr)]">
          <div className="space-y-6">
            <Card title={editingSpecialtyId ? "Editar Especialidade" : "Nova Especialidade"}>
              <form className="space-y-6" onSubmit={handleSpecialtySubmit}>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-slate-500 uppercase ml-1">Nome da Especialidade</label>
                    <input
                      className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                      value={specialtyForm.name}
                      onChange={(event) => handleSpecialtyFieldChange("name", event.target.value)}
                      placeholder="Ex.: Psicologia"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-500 uppercase ml-1">Descrição</label>
                    <textarea
                      className="mt-2 min-h-[96px] w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                      value={specialtyForm.description}
                      onChange={(event) => handleSpecialtyFieldChange("description", event.target.value)}
                      placeholder="Resumo operacional da Especialidade, observações e regra de uso."
                    />
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <label className="text-xs font-bold text-slate-500 uppercase ml-1">Origem da Demanda</label>
                      <select
                        className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                        value={specialtyForm.demandSourceMode}
                        onChange={(event) => {
                          const nextMode = event.target.value;
                          setSpecialtyForm((current) => ({
                            ...current,
                            demandSourceMode: nextMode,
                            defaultDemandId:
                              nextMode === REPORT_SPECIALTY_DEMAND_SOURCE_MODES.SYSTEM_DEFAULT
                                ? current.defaultDemandId
                                : "",
                          }));
                        }}
                      >
                        <option value={REPORT_SPECIALTY_DEMAND_SOURCE_MODES.EXCEL}>Demanda do arquivo</option>
                        <option value={REPORT_SPECIALTY_DEMAND_SOURCE_MODES.SYSTEM_DEFAULT}>Demanda do sistema</option>
                      </select>
                      <div className="mt-1 text-[11px] text-slate-500">
                        {specialtyModeToHint(specialtyForm.demandSourceMode)}
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-500 uppercase ml-1">Demanda padrão</label>
                      <select
                        className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700 disabled:bg-slate-50"
                        value={specialtyForm.defaultDemandId}
                        disabled={specialtyForm.demandSourceMode !== REPORT_SPECIALTY_DEMAND_SOURCE_MODES.SYSTEM_DEFAULT}
                        onChange={(event) => handleSpecialtyFieldChange("defaultDemandId", event.target.value)}
                      >
                        <option value="">
                          {specialtyDefaultDemandOptions.length
                            ? "Escolha a Demanda padrão"
                            : "Cadastre uma Demanda primeiro"}
                        </option>
                        {specialtyDefaultDemandOptions.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.name}
                          </option>
                        ))}
                      </select>
                      <div className="mt-1 text-[11px] text-slate-500">
                        Obrigatória quando a Especialidade usa Demanda do sistema.
                      </div>
                    </div>
                  </div>

                  <label className="inline-flex items-center gap-2 text-sm text-slate-700">
                    <input
                      type="checkbox"
                      checked={Boolean(specialtyForm.isActive)}
                      onChange={(event) => handleSpecialtyFieldChange("isActive", event.target.checked)}
                    />
                    Especialidade ativa para novos lotes
                  </label>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <Button type="submit" icon={Save} disabled={specialtyBusy}>
                    {specialtyBusy
                      ? editingSpecialtyId
                        ? "Salvando..."
                        : "Cadastrando..."
                      : editingSpecialtyId
                        ? "Salvar Especialidade"
                        : "Cadastrar Especialidade"}
                  </Button>

                  {editingSpecialtyId ? (
                    <Button type="button" variant="secondary" onClick={handleCancelEditSpecialty}>
                      Cancelar edição
                    </Button>
                  ) : null}
                </div>
              </form>
            </Card>

            <Card title="Especialidades cadastradas">
              <div className="space-y-4">
                <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                  <div className="text-sm font-semibold text-slate-800">Especialidades carregadas</div>
                  <div className="mt-1 text-3xl font-bold text-slate-900">
                    {specialtiesLoading ? "..." : specialties.length}
                  </div>
                  <div className="mt-1 text-sm text-slate-500">
                    Selecione uma Especialidade para liberar o cadastro de Demandas no painel da direita.
                  </div>
                </div>

                {!specialtiesLoading && !specialties.length ? (
                  <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-5 text-sm text-slate-500">
                    Nenhuma Especialidade cadastrada ainda.
                  </div>
                ) : null}

                {specialties.map((item) => {
                  const isSelected = String(item.id) === String(selectedSpecialtyId);
                  return (
                    <div
                      key={item.id}
                      className={`rounded-2xl border p-4 ${isSelected ? "border-violet-300 bg-violet-50/60" : "border-slate-100 bg-white"}`}
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div className="space-y-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <div className="text-lg font-semibold text-slate-900">{item.name}</div>
                            <Badge status={item.isActive ? "confirmed" : "pending"}>
                              {item.isActive ? "Ativa" : "Inativa"}
                            </Badge>
                            <Badge status="info">{specialtyModeToLabel(item.demandSourceMode)}</Badge>
                            {isSelected ? <Badge status="warning">Selecionada</Badge> : null}
                          </div>
                          <div className="text-sm text-slate-500">
                            {item.description || "Sem descrição informada."}
                          </div>
                          <div className="text-xs text-slate-500">
                            {item.demandsCount || 0} Demanda(s) cadastrada(s)
                            {item.defaultDemandName ? ` • Padrão: ${item.defaultDemandName}` : ""}
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          <Button type="button" variant="secondary" onClick={() => handleSelectSpecialty(item)}>
                            Usar
                          </Button>
                          <Button type="button" variant="secondary" onClick={() => handleEditSpecialty(item)} icon={PencilLine}>
                            Editar
                          </Button>
                          <Button
                            type="button"
                            variant="secondary"
                            onClick={() => handleToggleSpecialtyActive(item)}
                            disabled={specialtyBusy}
                          >
                            {item.isActive ? "Inativar" : "Ativar"}
                          </Button>
                          <Button
                            type="button"
                            variant="secondary"
                            onClick={() => handleDeleteSpecialty(item)}
                            icon={Trash2}
                            disabled={specialtyBusy}
                          >
                            Excluir
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>

          <div className="space-y-6">
            <Card
              title={
                selectedSpecialty
                  ? editingSpecialtyDemandId
                    ? `Editar Demanda • ${selectedSpecialty.name}`
                    : `Nova Demanda • ${selectedSpecialty.name}`
                  : "Demandas da Especialidade"
              }
            >
              {!selectedSpecialty ? (
                <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-6 text-sm text-slate-500">
                  Cadastre ou selecione uma Especialidade no painel da esquerda para liberar as Demandas.
                </div>
              ) : (
                <form className="space-y-6" onSubmit={handleSpecialtyDemandSubmit}>
                  <div className="rounded-xl border border-violet-100 bg-violet-50 px-4 py-3 text-sm text-violet-800">
                    <div className="font-semibold">{selectedSpecialty.name}</div>
                    <div className="mt-1">
                      Regra atual: <b>{specialtyModeToLabel(selectedSpecialty.demandSourceMode)}</b>
                    </div>
                    <div className="mt-1 text-violet-700">
                      {specialtyModeToHint(selectedSpecialty.demandSourceMode)}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="text-xs font-bold text-slate-500 uppercase ml-1">Nome da Demanda</label>
                      <input
                        className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                        value={specialtyDemandForm.name}
                        onChange={(event) => handleSpecialtyDemandFieldChange("name", event.target.value)}
                        placeholder="Ex.: Avaliação inicial"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-500 uppercase ml-1">Descrição geral</label>
                      <textarea
                        className="mt-2 min-h-[110px] w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                        value={specialtyDemandForm.description}
                        onChange={(event) => handleSpecialtyDemandFieldChange("description", event.target.value)}
                        placeholder="Contexto da Demanda, observações gerais e uso interno..."
                      />
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase ml-1">CID Inf</label>
                        <input
                          className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                          value={specialtyDemandForm.cidInf}
                          onChange={(event) => handleSpecialtyDemandFieldChange("cidInf", event.target.value)}
                          placeholder="Ex.: F90 / CID infantil"
                        />
                        <div className="mt-1 text-[11px] text-slate-500">
                          Usado quando a data de nascimento indicar paciente com menos de 18 anos.
                        </div>
                      </div>

                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase ml-1">CID Adult</label>
                        <input
                          className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                          value={specialtyDemandForm.cidAdult}
                          onChange={(event) => handleSpecialtyDemandFieldChange("cidAdult", event.target.value)}
                          placeholder="Ex.: F41 / CID adulto"
                        />
                        <div className="mt-1 text-[11px] text-slate-500">
                          Fallback padrão quando a data de nascimento estiver vazia ou inválida.
                        </div>
                      </div>
                    </div>

                    <label className="inline-flex items-center gap-2 text-sm text-slate-700">
                      <input
                        type="checkbox"
                        checked={Boolean(specialtyDemandForm.isActive)}
                        onChange={(event) => handleSpecialtyDemandFieldChange("isActive", event.target.checked)}
                      />
                      Demanda ativa para novos lotes
                    </label>

                    {REPORT_DEMAND_CATEGORY_OPTIONS.map((categoryNumber) => (
                      <div key={categoryNumber} className="rounded-2xl border border-slate-200 p-4">
                        <div className="text-sm font-semibold text-slate-900">Categoria {categoryNumber}</div>

                        <div className="mt-4 grid gap-4">
                          <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Título</label>
                            <input
                              className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                              value={specialtyDemandForm[`category${categoryNumber}Title`]}
                              onChange={(event) =>
                                handleSpecialtyDemandFieldChange(`category${categoryNumber}Title`, event.target.value)
                              }
                              placeholder={`Categoria ${categoryNumber}`}
                            />
                          </div>

                          <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Conteúdo</label>
                            <textarea
                              className="mt-2 min-h-[96px] w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                              value={specialtyDemandForm[`category${categoryNumber}Content`]}
                              onChange={(event) =>
                                handleSpecialtyDemandFieldChange(`category${categoryNumber}Content`, event.target.value)
                              }
                              placeholder={`Texto da Categoria ${categoryNumber}`}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <Button type="submit" icon={Save} disabled={specialtyDemandBusy}>
                      {specialtyDemandBusy
                        ? editingSpecialtyDemandId
                          ? "Salvando..."
                          : "Cadastrando..."
                        : editingSpecialtyDemandId
                          ? "Salvar Demanda"
                          : "Cadastrar Demanda"}
                    </Button>

                    {editingSpecialtyDemandId ? (
                      <Button type="button" variant="secondary" onClick={handleCancelEditSpecialtyDemand}>
                        Cancelar edição
                      </Button>
                    ) : null}
                  </div>
                </form>
              )}
            </Card>

            <Card title={selectedSpecialty ? `Demandas de ${selectedSpecialty.name}` : "Demandas da Especialidade"}>
              {!selectedSpecialty ? (
                <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-6 text-sm text-slate-500">
                  Escolha uma Especialidade para visualizar as Demandas cadastradas.
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                    <div className="text-sm font-semibold text-slate-800">Demandas carregadas</div>
                    <div className="mt-1 text-3xl font-bold text-slate-900">
                      {specialtyDemandsLoading ? "..." : specialtyDemands.length}
                    </div>
                    <div className="mt-1 text-sm text-slate-500">
                      {selectedSpecialty.demandSourceMode === REPORT_SPECIALTY_DEMAND_SOURCE_MODES.EXCEL
                        ? "Psicologia usa a Demanda do arquivo. Mantenha os nomes do sistema alinhados ao Excel."
                        : "Nutrição/Fonoaudiologia podem usar a Demanda padrão do sistema para gerar o relatório."}
                    </div>
                  </div>

                  {!specialtyDemandsLoading && !specialtyDemands.length ? (
                    <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-5 text-sm text-slate-500">
                      Nenhuma Demanda cadastrada para esta Especialidade ainda.
                    </div>
                  ) : null}

                  {specialtyDemands.map((item) => {
                    const isDefault = String(selectedSpecialty.defaultDemandId || "") === String(item.id);
                    return (
                      <div key={item.id} className="rounded-2xl border border-slate-100 p-4">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div className="space-y-2">
                            <div className="flex flex-wrap items-center gap-2">
                              <div className="text-lg font-semibold text-slate-900">{item.name}</div>
                              <Badge status={item.isActive ? "confirmed" : "pending"}>
                                {item.isActive ? "Ativa" : "Inativa"}
                              </Badge>
                              {isDefault ? <Badge status="warning">Padrão</Badge> : null}
                            </div>
                            <div className="text-sm text-slate-500">
                              {item.description || "Sem descrição informada."}
                            </div>
                            <div className="text-xs text-slate-500">{buildDemandPreviewLabel(item)}</div>
                          </div>

                          <div className="flex flex-wrap gap-2">
                            {selectedSpecialty.demandSourceMode === REPORT_SPECIALTY_DEMAND_SOURCE_MODES.SYSTEM_DEFAULT ? (
                              <Button
                                type="button"
                                variant="secondary"
                                onClick={() => handleSetDefaultDemandForSpecialty(item)}
                                disabled={specialtyBusy}
                              >
                                {isDefault ? "Demanda padrão" : "Definir padrão"}
                              </Button>
                            ) : null}
                            <Button type="button" variant="secondary" onClick={() => handleEditSpecialtyDemand(item)} icon={PencilLine}>
                              Editar
                            </Button>
                            <Button
                              type="button"
                              variant="secondary"
                              onClick={() => handleToggleSpecialtyDemandActive(item)}
                              disabled={specialtyDemandBusy}
                            >
                              {item.isActive ? "Inativar" : "Ativar"}
                            </Button>
                            <Button
                              type="button"
                              variant="secondary"
                              onClick={() => handleDeleteSpecialtyDemand(item)}
                              icon={Trash2}
                              disabled={specialtyDemandBusy}
                            >
                              Excluir
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
          </div>
        </div>
      )}

      {activeTab === "templates" && (
        <div className="grid gap-6 xl:grid-cols-[minmax(0,1.08fr)_minmax(360px,0.92fr)]">
          <div className="space-y-6">
            <Card title={editingTemplateId ? "Editar Modelo de Relatório" : "Novo Modelo de Relatório"}>
              <form className="space-y-6" onSubmit={handleTemplateSubmit}>
                <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_160px]">
                  <div>
                    <label className="text-xs font-bold text-slate-500 uppercase ml-1">Nome do modelo</label>
                    <input
                      className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                      value={templateForm.name}
                      onChange={(event) => handleTemplateFieldChange("name", event.target.value)}
                      placeholder="Ex.: Intermédica • padrão"
                    />
                  </div>

                  <label className="flex items-center gap-2 text-sm text-slate-600 mt-8">
                    <input
                      type="checkbox"
                      checked={Boolean(templateForm.isActive)}
                      onChange={(event) => handleTemplateFieldChange("isActive", event.target.checked)}
                      className="h-4 w-4 rounded border-slate-300 text-violet-600"
                    />
                    Modelo ativo
                  </label>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-500 uppercase ml-1">Descrição interna</label>
                  <textarea
                    className="mt-2 min-h-[90px] w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-700"
                    value={templateForm.description}
                    onChange={(event) => handleTemplateFieldChange("description", event.target.value)}
                    placeholder="Uso interno do modelo, convênio, layout, observações..."
                  />
                </div>

                <div className="rounded-2xl border border-violet-100 bg-violet-50/60 p-5">
                  <div className="text-sm font-semibold text-violet-900">Como este modelo funciona</div>
                  <div className="mt-2 text-sm leading-relaxed text-violet-800">
                    Você escreve o relatório na ordem exata em que ele deve aparecer no PDF. As <b>TAGS</b> abaixo são
                    substituídas automaticamente pelos dados da planilha, da Demanda e da categoria escolhida.
                  </div>
                </div>


                <div className="grid gap-6 xl:grid-cols-[minmax(0,1.25fr)_340px]">
                  <div className="space-y-5">
                    <div className="rounded-2xl border border-slate-100 p-4">
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <div className="text-sm font-semibold text-slate-900">Cabeçalho fixo</div>
                          <div className="mt-1 text-xs text-slate-500">
                            Use os botões para definir título, alinhamento e tamanho do texto.
                          </div>
                        </div>

                        <Button
                          type="button"
                          variant="secondary"
                          onClick={() => setActiveTemplateArea("headerTemplate")}
                        >
                          Inserir TAG aqui
                        </Button>
                      </div>

                      <div className="mt-4 space-y-3">
                        <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4">
                          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                            <div>
                              <div className="text-sm font-semibold text-slate-900">Logo da empresa</div>
                              <div className="mt-1 text-xs text-slate-500">
                                A logo será exibida acima do cabeçalho e no PDF. A imagem é convertida para JPG automaticamente.
                              </div>
                            </div>

                            <div className="flex flex-wrap gap-2">
                              <label className="inline-flex">
                                <input
                                  type="file"
                                  accept="image/*"
                                  className="hidden"
                                  onChange={handleTemplateLogoUpload}
                                />
                                <span className="inline-flex cursor-pointer items-center justify-center rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition hover:border-violet-300 hover:text-violet-700">
                                  Carregar logo
                                </span>
                              </label>

                              {templateForm.headerLogoDataUrl ? (
                                <Button type="button" variant="secondary" onClick={handleRemoveTemplateLogo} icon={Trash2}>
                                  Remover logo
                                </Button>
                              ) : null}
                            </div>
                          </div>

                          {templateForm.headerLogoDataUrl ? (
                            <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-white px-4 py-4">
                              <img
                                src={templateForm.headerLogoDataUrl}
                                alt="Logo do modelo"
                                className="max-h-16 w-auto max-w-[220px] object-contain"
                              />
                            </div>
                          ) : null}
                        </div>

                        <TemplateFormattingToolbar
                          onAction={(action) => handleTemplateFormattingAction("headerTemplate", action)}
                        />

                        <textarea
                          ref={headerTemplateRef}
                          className="min-h-[170px] w-full rounded-2xl border border-slate-200 px-4 py-3 font-mono text-sm text-slate-700"
                          value={templateForm.headerTemplate}
                          onFocus={() => setActiveTemplateArea("headerTemplate")}
                          onClick={() => setActiveTemplateArea("headerTemplate")}
                          onChange={(event) => handleTemplateTextChange("headerTemplate", event.target.value)}
                          placeholder={"[align=left][size=14][b]CLÍNICA EXEMPLO[/b][/size][/align]\nRua Exemplo, 123\n[align=left][size=13][b]RELATÓRIO CLÍNICO[/b][/size][/align]"}
                        />
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-100 p-4">
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <div className="text-sm font-semibold text-slate-900">Corpo do relatório</div>
                          <div className="mt-1 text-xs text-slate-500">
                            Agora você controla a ordem exata e também a aparência do texto no PDF.
                          </div>
                        </div>

                        <Button
                          type="button"
                          variant="secondary"
                          onClick={() => setActiveTemplateArea("bodyTemplate")}
                        >
                          Inserir TAG aqui
                        </Button>
                      </div>

                      <div className="mt-4 space-y-3">
                        <TemplateFormattingToolbar
                          onAction={(action) => handleTemplateFormattingAction("bodyTemplate", action)}
                        />

                        <textarea
                          ref={bodyTemplateRef}
                          className="min-h-[360px] w-full rounded-2xl border border-slate-200 px-4 py-3 font-mono text-sm text-slate-700"
                          value={templateForm.bodyTemplate}
                          onFocus={() => setActiveTemplateArea("bodyTemplate")}
                          onClick={() => setActiveTemplateArea("bodyTemplate")}
                          onChange={(event) => handleTemplateTextChange("bodyTemplate", event.target.value)}
                          placeholder={"[align=left][size=14][b]Ao convênio {{convenio}},[/b][/size][/align]\n\n[align=justify]O(a) paciente [b]{{paciente}}[/b] encontra-se em acompanhamento com [b]{{profissional}}[/b].[/align]\n\n[align=justify]{{categoria_conteudo}}[/align]"}
                        />
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-100 p-4">
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <div className="text-sm font-semibold text-slate-900">Rodapé fixo</div>
                          <div className="mt-1 text-xs text-slate-500">
                            Ideal para local/data, assinatura e observações finais.
                          </div>
                        </div>

                        <Button
                          type="button"
                          variant="secondary"
                          onClick={() => setActiveTemplateArea("footerTemplate")}
                        >
                          Inserir TAG aqui
                        </Button>
                      </div>

                      <div className="mt-4 space-y-3">
                        <TemplateFormattingToolbar
                          onAction={(action) => handleTemplateFormattingAction("footerTemplate", action)}
                        />

                        <textarea
                          ref={footerTemplateRef}
                          className="min-h-[180px] w-full rounded-2xl border border-slate-200 px-4 py-3 font-mono text-sm text-slate-700"
                          value={templateForm.footerTemplate}
                          onFocus={() => setActiveTemplateArea("footerTemplate")}
                          onClick={() => setActiveTemplateArea("footerTemplate")}
                          onChange={(event) => handleTemplateTextChange("footerTemplate", event.target.value)}
                          placeholder={"[hr]\n[align=center]{{cidade}}, {{data_geracao}}[/align]\n\n[align=center]_______________________________[/align]"}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Card title="TAGS automáticas" className="border border-slate-100">
                      <div className="mb-3 space-y-2 rounded-xl border border-slate-100 bg-slate-50 px-4 py-3 text-sm text-slate-600">
                        <div>
                          Área selecionada: <b>{activeTemplateArea === "headerTemplate" ? "Cabeçalho" : activeTemplateArea === "footerTemplate" ? "Rodapé" : "Corpo"}</b>
                        </div>
                        <div className="text-xs text-slate-500">
                          {"Agora as TAGS ficam em um seletor com busca, para mostrar todos os campos da planilha sem poluir a tela. A TAG {{cid}} escolhe automaticamente entre CID Inf e CID Adult conforme a data de nascimento."}
                        </div>
                      </div>
                      <TemplateTagToolbar onInsert={handleInsertTemplateTag} />
                    </Card>

                    <Card title="Atalhos de formatação" className="border border-slate-100">
                      <div className="space-y-3 text-sm text-slate-600">
                        <div className="rounded-xl border border-slate-100 bg-slate-50 px-4 py-3">
                          <div className="font-semibold text-slate-800">Como funciona</div>
                          <div className="mt-2">
                            Clique em um trecho do texto e use os botões para aplicar marcações como negrito, alinhamento e tamanho.
                          </div>
                        </div>

                        <div className="rounded-xl border border-slate-100 bg-slate-50 px-4 py-3">
                          <div className="font-semibold text-slate-800">Exemplo de título</div>
                          <div className="mt-2 whitespace-pre-wrap font-mono text-xs text-slate-600">
                            {"[align=center][size=16][b]RELATÓRIO CLÍNICO[/b][/size][/align]"}
                          </div>
                        </div>

                        <div className="rounded-xl border border-slate-100 bg-slate-50 px-4 py-3">
                          <div className="font-semibold text-slate-800">Exemplo de parágrafo</div>
                          <div className="mt-2 whitespace-pre-wrap font-mono text-xs text-slate-600">
                            {"[align=justify]O(a) paciente [b]{{paciente}}[/b] está em acompanhamento psicoterapêutico. CID: [b]{{cid}}[/b].[/align]"}
                          </div>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
                {!!(templateUnknownTokens.header.length || templateUnknownTokens.body.length || templateUnknownTokens.footer.length) && (
                  <div className="rounded-2xl border border-amber-100 bg-amber-50 px-4 py-4 text-sm text-amber-800 space-y-2">
                    <div className="font-semibold">TAGS não reconhecidas</div>
                    {templateUnknownTokens.header.length > 0 && (
                      <div><b>Cabeçalho:</b> {templateUnknownTokens.header.join(", ")}</div>
                    )}
                    {templateUnknownTokens.body.length > 0 && (
                      <div><b>Corpo:</b> {templateUnknownTokens.body.join(", ")}</div>
                    )}
                    {templateUnknownTokens.footer.length > 0 && (
                      <div><b>Rodapé:</b> {templateUnknownTokens.footer.join(", ")}</div>
                    )}
                  </div>
                )}

                <div className="flex flex-wrap gap-3">
                  <Button type="submit" disabled={templateBusy} icon={Save}>
                    {templateBusy ? "Salvando..." : editingTemplateId ? "Salvar alterações" : "Cadastrar modelo"}
                  </Button>

                  <Button type="button" variant="secondary" onClick={handleCancelEditTemplate}>
                    Cancelar edição
                  </Button>
                </div>
              </form>
            </Card>
          </div>

          <div className="space-y-6">
            <TemplateRenderedPreview
              templateForm={templateForm}
              previewRecord={templatePreviewRecord}
              selectedCategory={selectedCategory}
            />

            <Card title="Modelos cadastrados">
              <div className="space-y-3">
                {templatesLoading && (
                  <div className="rounded-xl border border-slate-100 bg-slate-50 px-4 py-3 text-sm text-slate-500">
                    Carregando modelos...
                  </div>
                )}

                {!templatesLoading && !templates.length && (
                  <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-500">
                    Nenhum modelo cadastrado ainda.
                  </div>
                )}

                {templates.map((item, index) => (
                  <div key={item.id || `${item.name}-${index}`} className="rounded-2xl border border-slate-100 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <div className="text-sm font-semibold text-slate-900">{item.name}</div>
                          {item.isActive && <Badge status="confirmed" text="Ativo" />}
                        </div>
                        <div className="mt-1 text-xs text-slate-500">{buildTemplateSummary(item)}</div>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <Button type="button" variant="secondary" onClick={() => handleEditTemplate(item)} icon={PencilLine}>
                          Editar
                        </Button>
                        <Button type="button" variant="secondary" onClick={() => handleToggleTemplateActive(item)}>
                          Ativar
                        </Button>
                        <Button type="button" variant="danger" onClick={() => handleDeleteTemplate(item)} icon={Trash2}>
                          Excluir
                        </Button>
                      </div>
                    </div>

                    {item.description && (
                      <div className="mt-3 rounded-xl border border-slate-100 bg-slate-50 px-4 py-3 text-sm text-slate-600">
                        {item.description}
                      </div>
                    )}

                    {item.bodyTemplate && (
                      <div className="mt-3 rounded-xl border border-slate-100 bg-slate-50 px-4 py-3 text-xs text-slate-500 whitespace-pre-wrap">
                        {String(item.bodyTemplate).split("\n").slice(0, 6).join("\n")}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </Card>

            <Card title="Como usar as TAGS">
              <div className="space-y-3 text-sm text-slate-600">
                <div className="rounded-xl border border-slate-100 bg-slate-50 px-4 py-3">
                  <div className="font-semibold text-slate-800">Exemplo prático</div>
                  <div className="mt-2 whitespace-pre-wrap font-mono text-xs text-slate-600">
                    {"Paciente: {{paciente}}\nProfissional: {{profissional}}\n\n{{categoria_titulo}}\n{{categoria_conteudo}}"}
                  </div>
                </div>

                <div className="rounded-xl border border-emerald-100 bg-emerald-50 px-4 py-3 text-emerald-800">
                  O PDF vai seguir exatamente a ordem em que você escrever o texto no editor.
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
