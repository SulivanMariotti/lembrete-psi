import { NextResponse } from "next/server";

import { requireAdmin } from "@/lib/server/requireAdmin";
import { analyzeReportImportFile, parseSelectedCategory } from "@/lib/server/reportImportAnalysis";
import { createReportImportSession } from "@/lib/server/reportImportSessions";
import { REPORT_IMPORT_TEMPLATE } from "@/lib/shared/reportImportTemplate";

export const runtime = "nodejs";

export async function POST(req) {
  const adminAuth = await requireAdmin(req);
  if (!adminAuth.ok) return adminAuth.res;

  try {
    const formData = await req.formData();
    const file = formData.get("file");
    const selectedCategory = parseSelectedCategory(formData.get("selectedCategory"));
    const templateId = String(formData.get("templateId") || "").trim();

    if (!file || typeof file.arrayBuffer !== "function") {
      return NextResponse.json(
        { ok: false, error: "Envie um arquivo .xlsx para importar." },
        { status: 400 }
      );
    }

    const extension = String(file.name || "")
      .trim()
      .toLowerCase()
      .slice(String(file.name || "").lastIndexOf("."));

    if (!REPORT_IMPORT_TEMPLATE.acceptedExtensions.includes(extension)) {
      return NextResponse.json(
        { ok: false, error: "Formato inválido. Envie uma planilha .xlsx." },
        { status: 400 }
      );
    }

    if (file.size > REPORT_IMPORT_TEMPLATE.maxFileSizeBytes) {
      return NextResponse.json(
        { ok: false, error: "Arquivo acima do limite permitido para pré-análise." },
        { status: 400 }
      );
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const analysis = await analyzeReportImportFile({
      buffer,
      fileName: file.name,
      fileSize: file.size,
      selectedCategory,
      templateId,
    });

    const assumptions = [
      ...analysis.assumptions,
      "O PDF final é gerado somente com linhas prontas para a categoria escolhida.",
      "O PDF final será gerado com base neste preview congelado até a expiração da sessão.",
    ];

    const session = await createReportImportSession({
      adminUid: adminAuth.uid,
      adminEmail: adminAuth.decoded?.email || null,
      fileName: analysis?.file?.name || file.name,
      fileSize: analysis?.file?.size || file.size,
      selectedCategory: analysis.selectedCategory,
      templateId: analysis?.selectedTemplate?.id || templateId || null,
      selectedTemplate: analysis.selectedTemplate,
      summary: analysis.summary,
      matchSummary: analysis.matchSummary,
      previewRows: analysis.previewRows,
      readyRows: analysis.readyRows,
      assumptions,
    });

    return NextResponse.json({
      ok: true,
      importSessionId: session.sessionId,
      expiresAt: session.expiresAt,
      template: analysis.template,
      selectedTemplate: analysis.selectedTemplate,
      file: analysis.file,
      workbook: analysis.workbook,
      validation: analysis.validation,
      summary: analysis.summary,
      selectedCategory: analysis.selectedCategory,
      matchSummary: analysis.matchSummary,
      previewRows: analysis.previewRows,
      importedAt: analysis.importedAt,
      assumptions,
    });
  } catch (error) {
    console.error("[admin/report/import] failed", error);

    if (error?.code === "invalid-template-headers") {
      return NextResponse.json(
        {
          ok: false,
          code: "invalid-template-headers",
          error: error?.message || "A planilha não corresponde ao template esperado.",
          validation: error?.validation || null,
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        ok: false,
        error: error?.message || "Não foi possível ler a planilha enviada.",
      },
      { status: 500 }
    );
  }
}
