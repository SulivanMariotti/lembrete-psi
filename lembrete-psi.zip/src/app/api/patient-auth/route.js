// src/app/api/patient-auth/route.js
import { NextResponse } from "next/server";
import admin from "@/lib/firebaseAdmin";
import { rateLimit } from "@/lib/server/rateLimit";
import { enforceSameOrigin } from "@/lib/server/originGuard";
import { asPlainObject, getString, unknownKeys, readJsonObjectBody } from "@/lib/server/payloadSchema";
export const runtime = "nodejs";
/**
 * Patient Login (email) - server-side (Firebase Admin)
 *
 * BUGFIXES:
 * - Autoriza consultando `users` (role == "patient") pelo email cadastrado no Admin.
 * - Bloqueia se paciente estiver inativo.
 * - Resistente a duplicidades antigas de `users` com o mesmo email:
 *   escolhe o doc "melhor" (prioriza o que tem telefone/phoneCanonical) para evitar
 *   casos em que o paciente entra num doc legado sem telefone.
 * - Se o doc escolhido estiver sem `phoneCanonical`, tenta preencher automaticamente
 *   (copiando de outro doc ativo com mesmo email ou derivando de campos existentes).
 *
 * Resposta:
 *   { ok: true, token, uid, phoneCanonical? }
 */

function legacyDisabled() {
  // Em produção, pareça que não existe.
  const status = process.env.NODE_ENV === "production" ? 404 : 410;
  const body =
    status === 404
      ? { ok: false, error: "Not found" }
      : {
          ok: false,
          error:
            "Login por e-mail está desativado por segurança. Use telefone + código de vinculação fornecido pela clínica.",
          hint:
            'Para habilitar APENAS em testes/legado, configure ENABLE_INSECURE_PATIENT_EMAIL_LOGIN="true" no servidor e NEXT_PUBLIC_ENABLE_INSECURE_PATIENT_EMAIL_LOGIN="true" no client.',
        };
  return NextResponse.json(body, { status });
}

function isInactiveUser(u) {
  const status = String(u?.status ?? "active").toLowerCase().trim();
  if (["inactive", "disabled", "archived", "deleted", "merged"].includes(status)) return true;
  if (u?.isActive === false) return true;
  if (u?.disabled === true) return true;
  if (u?.deletedAt) return true;
  if (u?.disabledAt) return true;
  if (u?.mergedTo) return true;
  return false;
}

function toMillis(ts) {
  if (!ts) return 0;
  if (typeof ts.toMillis === "function") return ts.toMillis();
  if (typeof ts.toDate === "function") return ts.toDate().getTime();
  if (ts instanceof Date) return ts.getTime();
  const n = Date.parse(String(ts));
  return Number.isFinite(n) ? n : 0;
}

function onlyDigits(v) {
  return String(v || "").replace(/\D/g, "");
}

/**
 * Canonical phone (projeto): DDD + número (10/11 dígitos), SEM 55
 */
function toPhoneCanonical(raw) {
  let d = onlyDigits(raw).replace(/^0+/, "");
  if (!d) return "";
  if (d.startsWith("55") && (d.length === 12 || d.length === 13)) d = d.slice(2);
  if (d.length === 10 || d.length === 11) return d;
  if (d.length > 11) return d.slice(-11);
  return d;
}

function hasAnyPhone(data) {
  return Boolean(
    String(data?.phoneCanonical || "").trim() ||
      String(data?.phone || "").trim() ||
      String(data?.phoneNumber || "").trim() ||
      String(data?.phoneE164 || "").trim()
  );
}

function pickBestUserDoc(items) {
  // Score:
  // - +1000 se tem telefone (evita escolher doc legado vazio)
  // - -100 se está marcado como mergedTo (por segurança)
  // - +recência (updatedAt/createdAt)
  let best = null;

  for (const item of items) {
    const d = item?.data || {};
    const hasPhone = hasAnyPhone(d);
    const isMerged = Boolean(d.mergedTo);
    const recency = toMillis(d.updatedAt) || toMillis(d.createdAt) || 0;

    // normaliza recência para não dominar totalmente a pontuação
    const score = (hasPhone ? 1000 : 0) + (isMerged ? -100 : 0) + recency / 1_000_000_000;

    if (!best || score > best.score) best = { ...item, score };
  }

  return best;
}

export async function POST(req) {
  try {
    const originCheck = enforceSameOrigin(req, {
      // Endpoint inseguro (email) - se habilitado, deve aceitar apenas mesma origem.
      allowNoOrigin: false,
      allowNoOriginWithAuth: false,
      message: "Acesso bloqueado (origem inválida).",
    });
    if (!originCheck.ok) return originCheck.res;

    // Rate limit (mesmo desativado por padrão, evita abuso quando habilitado em testes)
    const rl = await rateLimit(req, {
      bucket: "auth:patient:email",
      global: true,
      limit: 10,
      windowMs: 10 * 60_000,
      errorMessage: "Muitas tentativas. Aguarde alguns minutos e tente novamente.",
    });
    if (!rl.ok) return rl.res;

    // 🔒 Segurança: login por e-mail do paciente é INSEGURO sem verificação (OTP/Magic Link).
    // Mantemos o endpoint apenas para testes controlados e legado.
    // Em produção, deixe DESATIVADO (padrão). Para habilitar conscientemente, set:
    //   ENABLE_INSECURE_PATIENT_EMAIL_LOGIN="true"
    const enabled = String(process.env.ENABLE_INSECURE_PATIENT_EMAIL_LOGIN || "").toLowerCase() === "true";
    if (!enabled) {
      return legacyDisabled();
    }

    const bodyRes = await readJsonObjectBody(req, {
      maxBytes: 20_000,
      defaultValue: {},
      allowedKeys: ["email"],
      label: "patient-auth-legacy-email",
      showKeys: true,
    });
    if (!bodyRes.ok) return NextResponse.json({ ok: false, error: bodyRes.error }, { status: 400 });
    const rawBody = bodyRes.value;

    const po = asPlainObject(rawBody);
    if (!po.ok) {
      return NextResponse.json({ ok: false, error: po.error }, { status: 400 });
    }

    const uk = unknownKeys(po.value, ["email"]);
    if (uk.length) {
      return NextResponse.json({ ok: false, error: "Payload inválido." }, { status: 400 });
    }

    const emailRes = getString(po.value, "email", {
      required: true,
      trim: true,
      toLower: true,
      max: 254,
      maxBytes: 400,
      // validação simples: evita payloads estranhos, sem tentar "validar RFC"
      pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      label: "E-mail",
    });
    if (!emailRes.ok) {
      return NextResponse.json({ ok: false, error: emailRes.error }, { status: 400 });
    }

    const email = emailRes.value;

    const db = admin.firestore();

    // Authorize based on users collection (Admin cadastro)
    const q = await db
      .collection("users")
      .where("role", "==", "patient")
      .where("email", "==", email)
      .get();

    if (q.empty) {
      return NextResponse.json(
        { ok: false, error: "E-mail não autorizado. Solicite cadastro à clínica." },
        { status: 403 }
      );
    }

    const candidates = q.docs.map((doc) => ({ id: doc.id, data: doc.data() || {} }));
    const activeCandidates = candidates.filter((c) => !isInactiveUser(c.data));

    if (!activeCandidates.length) {
      return NextResponse.json(
        { ok: false, error: "Cadastro inativo. Fale com a clínica para reativação." },
        { status: 403 }
      );
    }

    // Escolher o melhor doc para evitar cair em duplicado sem telefone
    const chosen = pickBestUserDoc(activeCandidates) || activeCandidates[0];
    const uid = chosen.id;
    const userData = chosen.data || {};

    // Garantir phoneCanonical no doc escolhido (se possível)
    let phoneCanonical = toPhoneCanonical(
      userData?.phoneCanonical || userData?.phone || userData?.phoneNumber || userData?.phoneE164 || ""
    );

    if (!phoneCanonical) {
      // tenta copiar de outro doc ativo com mesmo email
      for (const c of activeCandidates) {
        const d = c?.data || {};
        const probe = toPhoneCanonical(d?.phoneCanonical || d?.phone || d?.phoneNumber || d?.phoneE164 || "");
        if (probe) {
          phoneCanonical = probe;
          break;
        }
      }
    }

    // Update lastLogin + (opcional) phoneCanonical/phone
    const now = admin.firestore.FieldValue.serverTimestamp();
    const patch = { lastLogin: now, updatedAt: now };

    if (phoneCanonical) {
      const existingPc = toPhoneCanonical(userData?.phoneCanonical || "");
      const existingFromPhone = toPhoneCanonical(userData?.phone || "");

      if (!existingPc || existingPc !== phoneCanonical) patch.phoneCanonical = phoneCanonical;
      // manter `phone` consistente com o que as rules usam (comparação com appointments.resource.data.phone)
      if (!existingFromPhone || existingFromPhone !== phoneCanonical) patch.phone = phoneCanonical;
    }

    await db.collection("users").doc(uid).set(patch, { merge: true });

    // Custom token with claims (keeps email for client convenience)
    const token = await admin.auth().createCustomToken(uid, { role: "patient", email });

    return NextResponse.json({ ok: true, token, uid, phoneCanonical: phoneCanonical || null });
  } catch (e) {
    console.error("[PATIENT_AUTH_EMAIL] Error", e);
    return NextResponse.json(
      { ok: false, error: "Erro interno. Tente novamente." },
      { status: 500 }
    );
  }
}